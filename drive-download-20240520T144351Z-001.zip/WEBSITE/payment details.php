<html>
    <head>
        <title>Make Reservation</title>
        <link href="./style.css" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    </head>
    <body>
        <h1 style="font-family: 'Impact';text-align:center;">Payment Details</h1>

        <div class="content">
            <form id="register" method="post">
                <label>Birthday Celebrant:</label><br><br>
                <label>Email:</label><br><br>
                <label>Age:</label><br><br>
                <label>Mobile Number:</label><br><br>
                <label>Gender:</label><br><br>
                <label>Place of venue:</label><br><br>
                <label>Package:</label><br><br>
                <label for="date">Date:</label><br><br>
                <label for="Time">Time of the party:</label><br><br>
                <label>Venue Details:</label><br><br>
                <label>Special Request:</label><br><br>
                <label>Name:</label><br><br>
                <label>Mode of Payment:</label><br><br>
            </form><br><br><br>
            <p>kfsdlfhlsdflkasdcmaskc</p>
            <a href="reservation.php">    
                    <input type="submit" value="Edit" name="submit" id="submit">
                </a>

    </body>

</html>