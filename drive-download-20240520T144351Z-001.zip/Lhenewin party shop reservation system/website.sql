-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Nov 22, 2023 at 12:15 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `website`
--

-- --------------------------------------------------------

--
-- Table structure for table `reserve`
--

CREATE TABLE `reserve` (
  `id` int(11) NOT NULL,
  `BirthdayCelebrant` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `contact` varchar(25) NOT NULL,
  `Gender` varchar(15) NOT NULL,
  `Place` varchar(100) NOT NULL,
  `Package` varchar(5) NOT NULL,
  `Price` varchar(30) NOT NULL,
  `Time` varchar(15) NOT NULL,
  `Request` varchar(100) NOT NULL,
  `Payment` varchar(30) NOT NULL,
  `Reference` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `reservation_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reserve`
--

INSERT INTO `reserve` (`id`, `BirthdayCelebrant`, `Email`, `contact`, `Gender`, `Place`, `Package`, `Price`, `Time`, `Request`, `Payment`, `Reference`, `status`, `reservation_date`) VALUES
(14, 'Alyzza Trovela', 'kimberlyannarboleda16@gmail.com', '', 'Female', '43 Balingasa Road', 'A', '1,800.00', '09:30', '', 'Walk in', '', 'reserved', '2023-11-17'),
(16, 'Brix', 'angbrixmarco@gmail.com', '09625423498', 'Male', 'Malabon city', 'M', '5,000.00', '15:30', 'awsdsfdsf', 'Gcash', 'REF799824265', 'reserved', '2023-11-29'),
(21, 'Kim', 'angbrixmarco@gmail.com', '0995315463592', 'Female', 'Caloocan City', 'B', '2,500.00', '16:47', 'ada', 'Walk in', '', 'reserved', '2023-11-26'),
(22, 'Tricia', 'angbrixmarco@gmail.com', '095136978516', 'Female', 'Valenzuela City', 'A', '1,800.00', '13:50', 'sjhdushdhsu', 'Walk in', '', 'settled', '2024-11-24'),
(23, 'Ann Analene', 'angbrixmarco@gmail.com', '09632546983', 'Female', 'Caloocan City', 'C', '2,500.00', '15:53', 'jguyiuohi', 'Gcash', 'REF799824234', 'settled', '2023-10-23'),
(24, 'Queenie', 'angbrixmarco@gmail.com', '09326459862', 'Female', 'Valenzuela City', 'D', '2,800.00', '15:54', 'Nothing', 'Gcash', 'REF799824265', 'reserved', '2023-11-26'),
(25, 'Jeremiah', 'angbrixmarco@gmail.com', '09326158621', 'Male', 'Valenzuela City', 'E', '3,000.00', '17:55', 'Nothing', 'Walk in', '', 'pending', '2024-01-02'),
(26, 'James', 'angbrixmarco@gmail.com', '0932649523165', 'Male', 'Caloocan City', 'F', '3,200.00', '', 'Nothing', 'Gcash', 'REF799824265', 'pending', '2023-11-18'),
(27, 'Taylor Swift', 'angbrixmarco@gmail.com', '09632548632', 'Female', 'Caloocan City', 'J', '4,200.00', '16:00', 'Nothing', 'Gcash', 'REF799824265', 'reserved', '2023-11-08'),
(28, 'Olivia Rodrigo', 'angbrixmarco@gmail.com', '09623541368', 'Female', 'Caloocan City', 'H', '3,800.00', '14:02', 'Nothing', 'Walk in', '', 'settled', '2023-11-05'),
(29, 'Harry Styles', 'angbrixmarco@gmail.com', '09326856321', 'Male', 'malabon', 'I', '4,000.00', '14:04', 'Nothing', 'Gcash', 'REF799824265', 'settled', '2023-10-15'),
(30, 'Queenie', 'queeniemoral2128@gmail.com', '09652368745', 'Male', 'Valenzuela City', 'Q', '6,500.00', '07:00', 'tydrdhjjhgfd', 'Gcash', 'RFjfhkdjhrf', 'pending', '2024-04-11'),
(31, '', 'queeniemoral2128gmail.com', '0963226454896', 'Male', '', 'A', '1,800.00', '', '', 'Walk in', '', 'pending', '2023-12-01'),
(32, 'Brixlyn', 'angbrixmarco1@gmail.com', '09632687456', 'Male', 'malabon', 'E', '3,000.00', '09:59', 'djfksjfsdkfghj', 'Gcash', 'edrfghj', 'pending', '2023-12-14'),
(33, 'Queen', 'queeniemoral2128@gmail.com', '09635698562', 'Female', 'Felo 1 covered court, Rincon,Valenzuela City', 'p', '4,500.00', '14:00', '', 'Walk in', '', 'reserved', '2023-12-12'),
(34, 'Ace Craige', 'queeniemoral2128@gmail.com', '09658563241', 'Male', 'Quezon CIty', 'D', '2,800.00', '09:00', '', 'Walk in', '', 'reserved', '2023-12-09'),
(36, 'King', 'queeniemoral2128@gmail.com', '09685032040', 'Male', 'Valenzuela City', 'b', '2,500.00', '04:53', '', 'Walk in', '', 'settled', '2023-07-20'),
(37, 'Heart', 'queeniemoral2128@gmail.com', '09562368748', 'Female', 'Valenzuela', 'a', '1,800.00', '12:00', '', 'Walk in', '', 'reserved', '2023-11-26'),
(38, 'Shai', 'queeniemoral2128@gmail.com', '09562368742', 'Female', 'Val City', 'p', '6,000.00', '08:00', '', 'Walk in', '', 'pending', '2023-11-30'),
(39, 'Jhane', 'queeniemoral2128@gmail.com', '09232187841', 'Male', 'Val enzuela CIty', 'p', '6,000.00', '13:00', '', 'Walk in', '', 'settled', '2023-11-18');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cancel`
--

CREATE TABLE `tbl_cancel` (
  `cancelID` bigint(20) NOT NULL,
  `numberOfCancel` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_cancel`
--

INSERT INTO `tbl_cancel` (`cancelID`, `numberOfCancel`) VALUES
(1, 10),
(2, 9),
(3, 15),
(4, 17),
(5, 18),
(6, 19),
(7, 20),
(8, 11),
(9, 35);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_services`
--

CREATE TABLE `tbl_services` (
  `packageCode` varchar(11) NOT NULL,
  `poster` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `clown` varchar(50) NOT NULL,
  `facepainter` varchar(50) NOT NULL,
  `details` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_services`
--

INSERT INTO `tbl_services` (`packageCode`, `poster`, `price`, `clown`, `facepainter`, `details`) VALUES
('a', 'a.jpg', 1800, '2', '0', 'dasdwer\r\ndsadsad'),
('b', 'b.jpg', 2500, '1', '1', ''),
('c', 'c.jpg', 2500, '2', '1', ''),
('d', 'd.jpg', 2800, '2', '0', ''),
('e', 'e.jpg', 3000, '2', '0', ''),
('f', 'f.jpg', 3200, '2', '1', ''),
('g', 'g.jpg', 3500, '2', '1', ''),
('h', 'h.jpg', 3800, '2', '0', ''),
('i', 'i.jpg', 4000, '2', '1', ''),
('j', 'j.jpg', 4200, '2', '1', ''),
('k', 'k.jpg', 4500, '2', '1', ''),
('l', 'l.jpg', 4800, '0', '0', ''),
('m', 'm.jpg', 5000, '0', '0', ''),
('n', 'n.jpg', 5500, '0', '0', ''),
('o', 'o.jpg', 5800, '2', '0', ''),
('p', 'p.jpg', 6000, '2', '0', 'Professional Magician\r\nGame Handling\r\nHosting\r\nMagic show\r\nwith live dove act\r\n1 CLown Assistant\r\n\r\nFreebies:\r\n20 pcs Toy pack\r\n10 Ballontwist'),
('q', 'q.jpg', 6500, '2', '0', 'bdhsadgwqy');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` bigint(20) NOT NULL,
  `First_Name` varchar(30) NOT NULL,
  `Last_Name` varchar(30) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `First_Name`, `Last_Name`, `Email`, `Phone`, `Password`, `Address`) VALUES
(2, 'queenie', 'moral', 'queeniemoral2128@gmail.com', '09269703612', 'Queenvic21@', 'valenzuela city'),
(15, 'Ramon', 'Rodriguez', 'ramon0991717171@gmail.com', '098826232', 'Cedd091717171', 'caloocan city'),
(16, 'juan', 'carlos', 'carlos@gmail.com', '0951124270', 'Carlos21', 'valenzuela city'),
(17, 'Kimberly Ann', 'Arboleda', 'kimberlyannarboleda16@gmail.com', '09770225299', '3613498Cali', '43 Balingasa Road'),
(18, 'brix', 'marco', 'angbrixmarco@gmail.com', '09915077974', 'Brixmarco23', 'blk37 lot 5 gulayan,catmon maabon city'),
(19, 'Kimberly', 'Arboleda', 'kimberlyannarboleda16@gmail.com', '09770225277', '13498Cali', ''),
(20, 'Kimberly', 'Arboleda', 'kimberlyannarboleda16@gmail.com', '09770225277', '3613498Kim', '43 Balingasa Road '),
(21, 'Kimberly', 'Arboleda', 'kimberlyannarboleda16@gmail.com', '09269703612', 'Arboleda21@', '43 Balingasa Road '),
(22, 'brix', 'ang', 'angbrixmarco1@gmail.com', '09515949774', 'Brixmarco23', '43 Balingasa Road ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reserve`
--
ALTER TABLE `reserve`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_cancel`
--
ALTER TABLE `tbl_cancel`
  ADD PRIMARY KEY (`cancelID`);

--
-- Indexes for table `tbl_services`
--
ALTER TABLE `tbl_services`
  ADD PRIMARY KEY (`packageCode`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `reserve`
--
ALTER TABLE `reserve`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `tbl_cancel`
--
ALTER TABLE `tbl_cancel`
  MODIFY `cancelID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
