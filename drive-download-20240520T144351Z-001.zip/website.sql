-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2023 at 05:13 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `website`
--

-- --------------------------------------------------------

--
-- Table structure for table `reserve`
--

CREATE TABLE `reserve` (
  `id` int(11) NOT NULL,
  `BirthdayCelebrant` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Gender` varchar(15) NOT NULL,
  `Place` varchar(100) NOT NULL,
  `Package` varchar(5) NOT NULL,
  `Price` varchar(30) NOT NULL,
  `Time` varchar(15) NOT NULL,
  `Request` varchar(100) NOT NULL,
  `Payment` varchar(30) NOT NULL,
  `Reference` varchar(50) NOT NULL,
  `Year` int(11) DEFAULT NULL,
  `Month` varchar(30) DEFAULT NULL,
  `Day` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reserve`
--

INSERT INTO `reserve` (`id`, `BirthdayCelebrant`, `Email`, `Gender`, `Place`, `Package`, `Price`, `Time`, `Request`, `Payment`, `Reference`, `Year`, `Month`, `Day`) VALUES
(14, 'Alyzza Trovela', 'kimberlyannarboleda16@gmail.com', 'Female', '43 Balingasa Road', 'A', '1,800.00', '09:30', '', 'Walk in', '', 2001, 'August', 9),
(16, 'Brix', 'angbrixmarco@gmail.com', 'Male', 'Malabon city', 'M', '5,000.00', '15:30', 'awsdsfdsf', 'Gcash', 'REF799824265', 2024, 'February', 23),
(21, 'Kim', 'angbrixmarco@gmail.com', 'Female', 'Caloocan City', 'B', '2,500.00', '16:47', 'ada', 'Walk in', '', 2023, 'March', 1),
(22, 'Tricia', 'angbrixmarco@gmail.com', 'Female', 'Valenzuela City', 'A', '1,800.00', '13:50', 'sjhdushdhsu', 'Walk in', '', 2023, 'April', 5),
(23, 'Ann Analene', 'angbrixmarco@gmail.com', 'Female', 'Caloocan City', 'C', '2,500.00', '15:53', 'jguyiuohi', 'Gcash', 'REF799824234', 2023, 'August', 19),
(24, 'Queenie', 'angbrixmarco@gmail.com', 'Female', 'Valenzuela City', 'D', '2,800.00', '15:54', 'Nothing', 'Gcash', 'REF799824265', 2023, 'June', 1),
(25, 'Jeremiah', 'angbrixmarco@gmail.com', 'Male', 'Valenzuela City', 'E', '3,000.00', '17:55', 'Nothing', 'Walk in', '', 2024, 'July', 1),
(26, 'James', 'angbrixmarco@gmail.com', 'Male', 'Caloocan City', 'F', '3,200.00', '', 'Nothing', 'Gcash', 'REF799824265', 2024, 'February', 5),
(27, 'Taylor Swift', 'angbrixmarco@gmail.com', 'Female', 'Caloocan City', 'J', '4,200.00', '16:00', 'Nothing', 'Gcash', 'REF799824265', 2023, 'December', 13),
(28, 'Olivia Rodrigo', 'angbrixmarco@gmail.com', 'Female', 'Caloocan City', 'H', '3,800.00', '14:02', 'Nothing', 'Walk in', '', 2023, 'May', 4),
(29, 'Harry Styles', 'angbrixmarco@gmail.com', 'Male', 'malabon', 'I', '4,000.00', '14:04', 'Nothing', 'Gcash', 'REF799824265', 2024, 'January', 18),
(30, 'Queenie', 'queeniemoral2128@gmail.com', 'Male', 'Valenzuela City', 'Q', '6,500.00', '07:00', 'tydrdhjjhgfd', 'Gcash', 'RFjfhkdjhrf', 2023, 'November', 20),
(31, '', 'queeniemoral2128gmail.com', 'Male', '', 'A', '1,800.00', '', '', 'Walk in', '', 2023, 'January', 1),
(32, 'Brixlyn', 'angbrixmarco1@gmail.com', 'Male', 'malabon', 'E', '3,000.00', '09:59', 'djfksjfsdkfghj', 'Gcash', 'edrfghj', 2023, 'November', 21);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cancel`
--

CREATE TABLE `tbl_cancel` (
  `cancelID` bigint(20) NOT NULL,
  `numberOfCancel` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_cancel`
--

INSERT INTO `tbl_cancel` (`cancelID`, `numberOfCancel`) VALUES
(1, 10),
(2, 9),
(3, 15),
(4, 17),
(5, 18),
(6, 19),
(7, 20),
(8, 11);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` bigint(20) NOT NULL,
  `First_Name` varchar(30) NOT NULL,
  `Last_Name` varchar(30) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `First_Name`, `Last_Name`, `Email`, `Phone`, `Password`, `Address`) VALUES
(2, 'queenie', 'moral', 'queeniemoral2128@gmail.com', '09269703612', 'Queenvic21@', 'valenzuela city'),
(15, 'Ramon', 'Rodriguez', 'ramon0991717171@gmail.com', '098826232', 'Cedd091717171', 'caloocan city'),
(16, 'juan', 'carlos', 'carlos@gmail.com', '0951124270', 'Carlos21', 'valenzuela city'),
(17, 'Kimberly Ann', 'Arboleda', 'kimberlyannarboleda16@gmail.com', '09770225299', '3613498Cali', '43 Balingasa Road'),
(18, 'brix', 'marco', 'angbrixmarco@gmail.com', '09915077974', 'Brixmarco23', 'blk37 lot 5 gulayan,catmon maabon city'),
(19, 'Kimberly', 'Arboleda', 'kimberlyannarboleda16@gmail.com', '09770225277', '13498Cali', ''),
(20, 'Kimberly', 'Arboleda', 'kimberlyannarboleda16@gmail.com', '09770225277', '3613498Kim', '43 Balingasa Road '),
(21, 'Kimberly', 'Arboleda', 'kimberlyannarboleda16@gmail.com', '09269703612', 'Arboleda21@', '43 Balingasa Road '),
(22, 'brix', 'ang', 'angbrixmarco1@gmail.com', '09515949774', 'Brixmarco23', '43 Balingasa Road ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reserve`
--
ALTER TABLE `reserve`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_cancel`
--
ALTER TABLE `tbl_cancel`
  ADD PRIMARY KEY (`cancelID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `reserve`
--
ALTER TABLE `reserve`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `tbl_cancel`
--
ALTER TABLE `tbl_cancel`
  MODIFY `cancelID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
